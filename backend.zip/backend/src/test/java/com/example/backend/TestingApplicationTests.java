package com.example.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
